﻿using AlgoritmoElevador.Input;
using AlgoritmoElevador.Model;
using AlgoritmoElevador.Output;

namespace AlgoritmoElevador.Strategy
{
    public interface ITravel
    {
        Passanger CreatePassanger(int floor, int accessibility);
        OutputTravel Register(InputTravel input);
    }
}
