﻿using System;
using AlgoritmoElevador.Input;
using AlgoritmoElevador.Model;
using AlgoritmoElevador.Output;

namespace AlgoritmoElevador.Strategy
{
    public class Handicapped : ITravel
    {
        public Passanger CreatePassanger(int floor, int accessibility)
        {
            throw new NotImplementedException();
        }

        public OutputTravel Register(InputTravel input)
        {
            throw new NotImplementedException();
        }
    }
}
