﻿using AlgoritmoElevador.Model;

namespace AlgoritmoElevador.Input
{
    public class InputTravel
    {
       public Passanger Passanger { get; set; }
    }
}
