﻿namespace AlgoritmoElevador.Enum
{
    public enum Accessibility
    {
        Handicapped = 1,
        Regular = 2
    }
}
