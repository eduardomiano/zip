﻿namespace AlgoritmoElevador.Domain.Enum
{
    public enum Itineration
    {
        Stoped = 0,
        MoveUp = 1,
        ComeDown = 2
    }
}
