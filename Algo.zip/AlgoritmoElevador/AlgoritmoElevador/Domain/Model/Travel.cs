﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AlgoritmoElevador.Domain.Enum;

namespace AlgoritmoElevador.Model
{
    public class Travel
    {
        public int ID { get; set; }
        public List<Passanger> Passanger { get; set; }
        public Itineration Itineration { get; set; }
    }
}
