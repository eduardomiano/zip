﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AlgoritmoElevador.Enum;

namespace AlgoritmoElevador.Model
{
    public class Passanger
    {
        public int ID { get; set; }
        public Accessibility Accessibility { get;set;}
    }
}
