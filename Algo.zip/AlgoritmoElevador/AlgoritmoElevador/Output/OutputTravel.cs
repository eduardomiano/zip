﻿namespace AlgoritmoElevador.Output
{
    public class OutputTravel
    {
        public string MessageOutput { get; set; }
    }
}
