﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AlgoritmoElevador.Engine;

namespace AlgoritmoElevador
{
    public class Program
    {
        static void Main(string[] args)
        {
            int floor = 0;
            int accessibility = 0;

            Console.WriteLine("Input Floor");
            floor = Int32.Parse(Console.ReadLine());

            Console.WriteLine("Input Accessibility");
            accessibility = Int32.Parse(Console.ReadLine());
            var result = LoadEngine(floor, accessibility);
            Console.WriteLine(result);
            Console.ReadLine();
        }

        private static string LoadEngine(int floor, int accessibility)
        {
            var engine = new ProcessEngine();
            var output = engine.StartProcess(floor, accessibility);
            return output.MessageOutput;
        }
    }
}
