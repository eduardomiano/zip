﻿using AlgoritmoElevador.Input;
using AlgoritmoElevador.Output;
using AlgoritmoElevador.Strategy;

namespace AlgoritmoElevador.Engine
{
    public class ProcessEngine
    {
        private const string TravelNotAvaiable = "Elevator Not Avaiable";
        public ITravel _travel;

        public ProcessEngine()
        {

        }

        public OutputTravel StartProcess(int floor, int accessibility)
        {
            if (!IsElevatorAvailable(floor, accessibility))
                return new OutputTravel {MessageOutput = TravelNotAvaiable};

            InputTravel input = new InputTravel();
            ParseTravel(accessibility);
            return _travel.Register(input);
        }

        private bool IsElevatorAvailable(int floor, int accessibility)
        {
            //Verifica se existe elevadores disponiveis
            return true;
        }
        
        private void ParseTravel(int accessibility)
        {
            switch (accessibility)
            {
                case 1:
                    _travel = new Handicapped();
                    break;
                case 2:
                    _travel = new Regular();
                    break;
                default:
                    _travel = new Regular();
                    break;
            }
        }
    }
}
